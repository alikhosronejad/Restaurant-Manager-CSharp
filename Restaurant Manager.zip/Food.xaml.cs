﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for Food.xaml
    /// </summary>
    public partial class Food : Window
    {
        public Food()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table FOOD. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.FOODTableAdapter restoranDataSetFOODTableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.FOODTableAdapter();
            restoranDataSetFOODTableAdapter.Fill(restoranDataSet.FOOD);
            System.Windows.Data.CollectionViewSource fOODViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("fOODViewSource")));
            fOODViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();
        }
    }
}
