﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for Employer.xaml
    /// </summary>
    public partial class Employer : Window
    {
        public Employer()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table RS_EMPL_ROLE. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.RS_EMPL_ROLETableAdapter restoranDataSetRS_EMPL_ROLETableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.RS_EMPL_ROLETableAdapter();
            restoranDataSetRS_EMPL_ROLETableAdapter.Fill(restoranDataSet.RS_EMPL_ROLE);
            System.Windows.Data.CollectionViewSource rS_EMPL_ROLEViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("rS_EMPL_ROLEViewSource")));
            rS_EMPL_ROLEViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }
    }
}
