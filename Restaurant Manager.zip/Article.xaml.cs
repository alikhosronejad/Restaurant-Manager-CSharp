﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for Article.xaml
    /// </summary>
    public partial class Article : Window
    {
        public Article()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table RS__ARTCILES. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.RS__ARTCILESTableAdapter restoranDataSetRS__ARTCILESTableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.RS__ARTCILESTableAdapter();
            restoranDataSetRS__ARTCILESTableAdapter.Fill(restoranDataSet.RS__ARTCILES);
            System.Windows.Data.CollectionViewSource rS__ARTCILESViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("rS__ARTCILESViewSource")));
            rS__ARTCILESViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }
    }
}
