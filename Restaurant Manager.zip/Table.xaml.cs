﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for Table.xaml
    /// </summary>
    public partial class Table : Window
    {
        public Table()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table RS_TABLE. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.RS_TABLETableAdapter restoranDataSetRS_TABLETableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.RS_TABLETableAdapter();
            restoranDataSetRS_TABLETableAdapter.Fill(restoranDataSet.RS_TABLE);
            System.Windows.Data.CollectionViewSource rS_TABLEViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("rS_TABLEViewSource")));
            rS_TABLEViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();
        }
    }
}
