﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for Food_Type.xaml
    /// </summary>
    public partial class Food_Type : Window
    {
        public Food_Type()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table FOOD_TYPE. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.FOOD_TYPETableAdapter restoranDataSetFOOD_TYPETableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.FOOD_TYPETableAdapter();
            restoranDataSetFOOD_TYPETableAdapter.Fill(restoranDataSet.FOOD_TYPE);
            System.Windows.Data.CollectionViewSource fOOD_TYPEViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("fOOD_TYPEViewSource")));
            fOOD_TYPEViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();
        }
    }
}
