﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for invoice.xaml
    /// </summary>
    public partial class invoice : Window
    {
        public invoice()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainForm = new MainWindow();
            MainForm.Show();
            this.Hide();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Restaurant_Manager.RestoranDataSet restoranDataSet = ((Restaurant_Manager.RestoranDataSet)(this.FindResource("restoranDataSet")));
            // Load data into the table FAKTOR. You can modify this code as needed.
            Restaurant_Manager.RestoranDataSetTableAdapters.FAKTORTableAdapter restoranDataSetFAKTORTableAdapter = new Restaurant_Manager.RestoranDataSetTableAdapters.FAKTORTableAdapter();
            restoranDataSetFAKTORTableAdapter.Fill(restoranDataSet.FAKTOR);
            System.Windows.Data.CollectionViewSource fAKTORViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("fAKTORViewSource")));
            fAKTORViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Error Establishing a Database Connection!");
        }
    }
}
