﻿using System.Windows;

namespace Restaurant_Manager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("By : Farzane Azimi & Ali Khosronejad");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Food_Type FTypeForm = new Food_Type();
            FTypeForm.Show();
            this.Hide();
    
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("www.irNanoSoft.ir");
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Food FoodForm = new Food();
            FoodForm.Show();
            this.Hide();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            invoice invoiceForm = new invoice();
            invoiceForm.Show();
            this.Hide();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            Customer CustomForm = new Customer();
            CustomForm.Show();
            this.Hide();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            Personnel PerForm = new Personnel();
            PerForm.Show();
            this.Hide();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            Article ArtForm = new Article();
            ArtForm.Show();
            this.Hide();
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            Employer EmpForm = new Employer();
            EmpForm.Show();
            this.Hide();
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            Payment PayForm = new Payment();
            PayForm.Show();
            this.Hide();
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            Table TabForm = new Table();
            TabForm.Show();
            this.Hide();
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            Table_Reservation TabResForm = new Table_Reservation();
            TabResForm.Show();
            this.Hide();
        }
    }
}
